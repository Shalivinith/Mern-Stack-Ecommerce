import styled from 'styled-components';

export const Row = styled.div`
  display: flex;
  flex-wrap: wrap;

  @media (min-width: 576px) {
  }
  @media (min-width: 992px) {
  }
`;
